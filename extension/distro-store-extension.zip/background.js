const PRODUCTION_APP = "https://distro-auu6.vercel.app";
const LOGIN_URL = `${PRODUCTION_APP}/login`;
const GROUPS_URL = "https://www.facebook.com/groups/joins/";

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason !== "install") return;
  chrome.tabs.create({ url: PRODUCTION_APP });
  chrome.tabs.create({ url: GROUPS_URL });
});

chrome.action.onClicked.addListener((tab) => {
  if (tab?.id && tab.url && tab.url.includes("facebook.com")) {
    chrome.tabs.sendMessage(tab.id, { action: "TOGGLE_DISTRO_SIDEBAR" }, () => {
      void chrome.runtime.lastError;
    });
    return;
  }
  chrome.tabs.create({ url: LOGIN_URL });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "AUTH_SUCCESS" && typeof message.token === "string") {
    chrome.storage.local.set(
      { sessionToken: message.token, authenticatedAt: Date.now() },
      () => sendResponse({ ok: true })
    );
    return true;
  }
  if (message?.type === "GET_AUTH") {
    chrome.storage.local.get(["sessionToken", "authenticatedAt"], (stored) => {
      sendResponse({
        authenticated: Boolean(stored.sessionToken),
        sessionToken: stored.sessionToken || null,
      });
    });
    return true;
  }
  return false;
});
