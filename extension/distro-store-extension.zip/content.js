(() => {
  const API_BASE = "https://distro-auu6.vercel.app";
  const SYNC_URL = `${API_BASE}/api/channels/sync`;
  const DASHBOARD_URL = `${API_BASE}/dashboard/channels`;
  const DISTRO_API_KEY = "zpv9dq136kwfxcn0t285hgoeajmlryi7ub4s";
  const PANEL_ID = "distro-sidebar-container";

  function scrapeFacebookGroups() {
    const byId = new Map();

    const NAME_NOISE = [
      /\s*פעילות אחרונה[\s\S]*$/i,
      /\s*פוסטים חדשים(?:\s+היום)?[\s\S]*$/i,
      /\s*Last active[\s\S]*$/i,
      /\s*Active now[\s\S]*$/i,
      /\s*New posts?(?:\s+today)?[\s\S]*$/i,
      /\s*[\d.,]+\s*(?:K|k|M|m|אלף|מיליון)?\s*(?:members?|חברים)[\s\S]*$/i,
      /\s*[·•|].*$/,
    ];

    const nameLooksNoisy = (name) =>
      /פעילות אחרונה|פוסטים חדשים|Last active|Active now|New posts?|members?|חברים/i.test(
        name || ""
      );

    const cleanGroupName = (raw) => {
      let name = (raw || "")
        .replace(/\u00a0/g, " ")
        .replace(/[\u200e\u200f\u202a-\u202e]/g, "")
        .replace(/\s+/g, " ")
        .trim();
      name = name.split(/\n/)[0].trim();
      for (const re of NAME_NOISE) {
        name = name.replace(re, "").trim();
      }
      return name;
    };

    const parseMembers = (text) => {
      if (!text) return undefined;
      const normalized = String(text)
        .replace(/,/g, "")
        .replace(/[\u00a0\u202f\u2009\u2007]/g, " ")
        .replace(/[\u200e\u200f]/g, "")
        .trim();
      const match = normalized.match(
        /([\d]+(?:\.[\d]+)?)\s*(K|k|M|m|אלף|מיליון)?/i
      );
      if (!match) return undefined;
      let n = parseFloat(match[1]);
      if (Number.isNaN(n)) return undefined;
      const suffix = (match[2] || "").toLowerCase();
      if (suffix === "k" || suffix === "אלף") n *= 1000;
      if (suffix === "m" || suffix === "מיליון") n *= 1_000_000;
      return Math.round(n);
    };

    const findMemberCount = (root) => {
      if (!root) return undefined;
      const shortNodes = root.querySelectorAll("span, div, a");
      for (const el of shortNodes) {
        const text = (el.textContent || "").replace(/\s+/g, " ").trim();
        if (!text || text.length > 48) continue;
        if (!/(?:members?|חברים)/i.test(text)) continue;
        if (!/\d/.test(text)) continue;
        const count = parseMembers(text);
        if (Number.isFinite(count) && count > 0) return count;
      }
      const blob = (root.innerText || root.textContent || "").replace(
        /\s+/g,
        " "
      );
      const patterns = [
        /([\d.,]+)\s*(K|k|M|m|אלף|מיליון)?\s*(?:members?|חברים)/i,
        /(?:members?|חברים)\s*:?\s*([\d.,]+)\s*(K|k|M|m|אלף|מיליון)?/i,
      ];
      for (const re of patterns) {
        const match = blob.match(re);
        if (!match) continue;
        const count = parseMembers(
          `${match[1]}${match[2] ? ` ${match[2]}` : ""}`
        );
        if (Number.isFinite(count) && count > 0) return count;
      }
      return undefined;
    };

    const findCard = (anchor) =>
      anchor.closest('[role="listitem"]') ||
      anchor.closest('[role="article"]') ||
      anchor.closest('[data-visualcompletion="ignore-dynamic"]') ||
      anchor.closest("div[role='row']") ||
      (() => {
        let node = anchor.parentElement;
        for (let i = 0; i < 6 && node; i += 1) {
          if (/(?:members?|חברים)/i.test(node.textContent || "")) return node;
          node = node.parentElement;
        }
        return anchor.parentElement?.parentElement || anchor.parentElement;
      })();

    const extractGroupName = (anchor, card) => {
      const candidates = [];
      const inLink =
        anchor.querySelector('span[dir="auto"]') ||
        anchor.querySelector("span") ||
        null;
      if (inLink?.textContent?.trim()) candidates.push(inLink.textContent);
      if (card) {
        for (const sel of [
          'a[role="link"] span[dir="auto"]',
          'a[role="link"] span',
          "h2",
          "h3",
          "strong",
        ]) {
          const el = card.querySelector(sel);
          if (el?.textContent?.trim()) candidates.push(el.textContent);
        }
      }
      const aria = anchor.getAttribute("aria-label");
      if (aria?.trim()) candidates.push(aria);

      let best = "";
      for (const raw of candidates) {
        const cleaned = cleanGroupName(raw);
        if (cleaned.length < 2) continue;
        if (!best) best = cleaned;
        if (!nameLooksNoisy(cleaned)) {
          if (nameLooksNoisy(best) || cleaned.length <= best.length) {
            best = cleaned;
          }
        }
      }
      return best || cleanGroupName(anchor.textContent || "");
    };

    const addGroup = (id, name, memberCount, url) => {
      if (!id || !/^\d+$/.test(String(id))) return;
      const cleanName = cleanGroupName(name);
      if (!cleanName || cleanName.length < 2) return;
      const nextCount = Number.isFinite(memberCount) ? memberCount : undefined;
      const prev = byId.get(id);
      if (!prev) {
        byId.set(id, {
          id: String(id),
          name: cleanName,
          memberCount: nextCount,
          url: url || `https://www.facebook.com/groups/${id}`,
        });
        return;
      }
      let bestName = prev.name;
      if (!nameLooksNoisy(cleanName) && nameLooksNoisy(prev.name)) {
        bestName = cleanName;
      } else if (
        !nameLooksNoisy(cleanName) &&
        cleanName.length > 0 &&
        cleanName.length < prev.name.length
      ) {
        bestName = cleanName;
      } else if (nameLooksNoisy(prev.name) && cleanName.length >= 2) {
        bestName = cleanName;
      }
      byId.set(id, {
        ...prev,
        name: bestName,
        memberCount: nextCount && nextCount > 0 ? nextCount : prev.memberCount,
        url: prev.url || url || `https://www.facebook.com/groups/${id}`,
      });
    };

    document.querySelectorAll('a[href*="/groups/"]').forEach((a) => {
      const href = a.href || a.getAttribute("href") || "";
      const m = href.match(/\/groups\/(\d+)/);
      if (!m) return;
      if (/\/groups\/\d+\/(user|members|permalink)/i.test(href)) return;
      const id = m[1];
      const card = findCard(a);
      addGroup(id, extractGroupName(a, card), findMemberCount(card), href.split("?")[0]);
    });

    if (byId.size === 0) {
      const html = document.documentElement.innerHTML;
      const re = /\/groups\/(\d{5,})/g;
      let match;
      while ((match = re.exec(html)) !== null) {
        addGroup(match[1], `Group ${match[1]}`);
      }
    }

    let fbUserName = "Facebook User";
    const profile =
      document.querySelector('[aria-label*="Your profile"]') ||
      document.querySelector('[aria-label*="הפרופיל שלך"]') ||
      document.querySelector('a[href*="/me"] span');
    if (profile?.textContent?.trim()) {
      fbUserName = profile.textContent.trim();
    }

    return {
      groups: Array.from(byId.values()),
      fbUserName,
      pageUrl: location.href,
    };
  }

  function readDocumentCookies() {
    return document.cookie
      .split(";")
      .map((part) => part.trim())
      .filter(Boolean)
      .map((part) => {
        const eq = part.indexOf("=");
        if (eq < 0) return null;
        return {
          name: part.slice(0, eq),
          value: decodeURIComponent(part.slice(eq + 1)),
          domain: ".facebook.com",
          path: "/",
        };
      })
      .filter(Boolean);
  }

  function getCookieValue(name) {
    const parts = document.cookie.split(";");
    for (const part of parts) {
      const trimmed = part.trim();
      if (trimmed.startsWith(`${name}=`)) {
        return decodeURIComponent(trimmed.slice(name.length + 1));
      }
    }
    return null;
  }

  function ensurePanel() {
    let panel = document.getElementById(PANEL_ID);
    if (panel) return panel;

    panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.setAttribute("dir", "ltr");
    panel.style.cssText = [
      "position:fixed",
      "top:72px",
      "right:16px",
      "z-index:2147483646",
      "width:300px",
      "background:#0f172a",
      "color:#f8fafc",
      "border:1px solid #334155",
      "border-radius:12px",
      "box-shadow:0 12px 40px rgba(0,0,0,.35)",
      "font-family:system-ui,-apple-system,sans-serif",
      "padding:16px",
      "display:none",
    ].join(";");

    panel.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:12px;">
        <strong style="letter-spacing:.08em;">DISTRO</strong>
        <button type="button" id="distro-close-btn" style="background:transparent;border:0;color:#94a3b8;cursor:pointer;font-size:16px;">×</button>
      </div>
      <p style="margin:0 0 12px;font-size:12px;color:#94a3b8;line-height:1.4;">
        Sync joined Facebook groups into your Distro dashboard.
      </p>
      <button type="button" id="distro-sync-btn" style="width:100%;border:0;border-radius:8px;padding:12px;font-weight:600;cursor:pointer;background:linear-gradient(180deg,#f8fafc,#e2e8f0);color:#0f172a;">
        Sync Groups
      </button>
      <div id="distro-status" style="margin-top:12px;font-size:12px;text-align:center;color:#94a3b8;"></div>
    `;

    document.documentElement.appendChild(panel);

    panel.querySelector("#distro-close-btn")?.addEventListener("click", () => {
      panel.style.display = "none";
    });
    panel.querySelector("#distro-sync-btn")?.addEventListener("click", () => {
      void runSync();
    });

    return panel;
  }

  function setStatus(message, tone) {
    const el = document.getElementById("distro-status");
    if (!el) return;
    el.textContent = message;
    el.style.color =
      tone === "ok" ? "#34d399" : tone === "err" ? "#f87171" : "#fbbf24";
  }

  function togglePanel() {
    const panel = ensurePanel();
    panel.style.display = panel.style.display === "none" ? "block" : "none";
  }

  async function runSync() {
    const btn = document.getElementById("distro-sync-btn");
    if (btn) btn.disabled = true;
    try {
      setStatus("Scanning groups…", "warn");
      const scraped = scrapeFacebookGroups();
      const groups = scraped.groups || [];
      if (!groups.length) {
        setStatus(
          "No groups found. Open facebook.com/groups/joins/ and try again.",
          "err"
        );
        return;
      }

      const fbUserId = getCookieValue("c_user");
      if (!fbUserId) {
        setStatus("Not logged into Facebook. Sign in, then sync again.", "err");
        return;
      }

      setStatus(`Found ${groups.length} groups — sending to Distro…`, "warn");

      const payload = {
        fbUserId,
        fbUserName: scraped.fbUserName || "Facebook User",
        groups,
        cookies: readDocumentCookies(),
      };

      const res = await fetch(SYNC_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-distro-key": DISTRO_API_KEY,
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) {
        throw new Error(data.error || `Server error (${res.status})`);
      }

      const token = data.extensionToken || data.handoffToken;
      if (typeof token === "string" && token) {
        chrome.runtime.sendMessage({ type: "AUTH_SUCCESS", token });
      }

      setStatus(
        `Synced ${data.syncedCount ?? groups.length} groups successfully.`,
        "ok"
      );

      const handoffPath =
        typeof data.handoffPath === "string" && data.handoffPath.startsWith("/")
          ? data.handoffPath
          : "/dashboard/channels";
      window.open(`${API_BASE}${handoffPath}`, "_blank", "noopener");
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Sync failed. Please try again.";
      setStatus(message, "err");
    } finally {
      if (btn) btn.disabled = false;
    }
  }

  chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    if (request?.action === "TOGGLE_DISTRO_SIDEBAR") {
      togglePanel();
      sendResponse({ ok: true });
      return true;
    }
    if (request?.action === "RUN_DISTRO_SYNC") {
      void runSync().then(() => sendResponse({ ok: true }));
      return true;
    }
    return false;
  });

  // Expose a stable hook for debugging without noisy logs
  window.__distroEnsurePanel = ensurePanel;
})();
